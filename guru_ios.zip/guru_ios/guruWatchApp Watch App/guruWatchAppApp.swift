//
//  guruWatchAppApp.swift
//  guruWatchApp Watch App
//
//  Created by yeseo on 2023/01/25.
//

import SwiftUI

@main
struct guruWatchApp_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
